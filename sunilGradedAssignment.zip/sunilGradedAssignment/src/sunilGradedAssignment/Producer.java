package sunilGradedAssignment;

public class Producer {
	Thread1 t1;

	Producer(Thread1 t1) {
		this.t1 = t1;
	}

}
