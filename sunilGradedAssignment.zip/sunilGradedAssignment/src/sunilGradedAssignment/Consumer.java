package sunilGradedAssignment;

public class Consumer {
	Thread1 t1;

	Consumer(Thread1 t1) {
		this.t1 = t1;
	}

}
