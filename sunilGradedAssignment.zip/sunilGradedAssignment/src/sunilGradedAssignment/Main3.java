package sunilGradedAssignment;

import java.util.Arrays;

public class Main3 {

	public static void main(String[] args) {
		int arr[] = {1,2,3,4,5};
		
		int sum =Arrays.stream(arr).filter(x -> x%2 !=0).map(x -> x*x).sum();
		
		System.out.println(sum);

	}
}
